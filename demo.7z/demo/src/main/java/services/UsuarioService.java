package services;

import models.Usuario;
import repositories.UsuarioRepository;

import java.util.List;
import java.util.Optional;

public class UsuarioService {

    private final UsuarioRepository usuarioRepository;

    public UsuarioService(UsuarioRepository usuarioRepository) {
        this.usuarioRepository = usuarioRepository;
    }
    public List<Usuario> obtenerTodos() {
        return usuarioRepository.findAll();
    }
    public Optional<Usuario> obtenerPorId(Long id) {
        return usuarioRepository.findById(id);
    }
    public Usuario crearUsuario(Usuario usuario) {
        return usuarioRepository.save(usuario);
    }

    public Usuario actualizarUsuario(Long id, Usuario usuario) {
        return  usuarioRepository.findById(id).map(existingUsuario -> {
            existingUsuario.setNombre(usuario.getNombre());
            existingUsuario.setEmail(usuario.getEmail());
            existingUsuario.setPassword(usuario.getPassword());
            return usuarioRepository.save(existingUsuario);
        }).orElseGet(() -> {
            usuario.setId(id);
            return usuarioRepository.save(usuario);
        });
    }

    public void eliminarUsuario(Long id) {
        usuarioRepository.deleteById(id);
    }
}
