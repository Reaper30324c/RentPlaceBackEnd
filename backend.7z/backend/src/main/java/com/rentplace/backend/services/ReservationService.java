package com.rentplace.backend.services;

import com.rentplace.backend.models.Reservation;
import com.rentplace.backend.repositories.ReservationRepository;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class ReservationService {

    private final ReservationRepository reservationRepository;

    public ReservationService(ReservationRepository reservationRepository) {
        this.reservationRepository = reservationRepository;
    }

    public List<Reservation> getAll() {
        return reservationRepository.findAll();
    }

    public Optional<Reservation> getById(Long id) {
        return reservationRepository.findById(id);
    }

    public Reservation createReservation(Reservation reservation) {
        return reservationRepository.save(reservation);
    }

    public Reservation updateReservation(Long id, Reservation reservation) {
        return reservationRepository.findById(id).map(existingReservation -> {
            existingReservation.setStartDate(reservation.getStartDate());
            existingReservation.setEndDate(reservation.getEndDate());
            existingReservation.setTotalCost(reservation.getTotalCost());
            // Update user or property if needed
            return reservationRepository.save(existingReservation);
        }).orElseGet(() -> {
            reservation.setId(id);
            return reservationRepository.save(reservation);
        });
    }

    public void deleteReservation(Long id) {
        reservationRepository.deleteById(id);
    }
}
