package com.rentplace.backend.services;

import com.rentplace.backend.models.Reservation;
import com.rentplace.backend.repositories.ReservationRepository;
import org.springframework.stereotype.Service;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Optional;

@Service
public class ReservationService {

    private final ReservationRepository reservationRepository;

    public ReservationService(ReservationRepository reservationRepository) {
        this.reservationRepository = reservationRepository;
    }

    public List<Reservation> getAllReservations() {
        return reservationRepository.findAll();
    }

    public Optional<Reservation> getReservationById(Long id) {
        return reservationRepository.findById(id);
    }

    public Reservation createReservation(Reservation reservation) {
        long nights = ChronoUnit.DAYS.between(reservation.getStartDate(), reservation.getEndDate());
        if (nights <= 0) {
            throw new IllegalArgumentException("End date must be after start date");
        }
        double computedCost = nights * reservation.getProperty().getPricePerNight();
        reservation.setTotalCost(computedCost);
        return reservationRepository.save(reservation);
    }

    public Reservation updateReservation(Long id, Reservation reservation) {
        return reservationRepository.findById(id).map(existingReservation -> {
            existingReservation.setStartDate(reservation.getStartDate());
            existingReservation.setEndDate(reservation.getEndDate());
            long nights = ChronoUnit.DAYS.between(reservation.getStartDate(), reservation.getEndDate());
            if (nights <= 0) {
                throw new IllegalArgumentException("End date must be after start date");
            }
            double computedCost = nights * reservation.getProperty().getPricePerNight();
            existingReservation.setTotalCost(computedCost);
            // Optionally update user and property if needed
            existingReservation.setUser(reservation.getUser());
            existingReservation.setProperty(reservation.getProperty());
            return reservationRepository.save(existingReservation);
        }).orElseGet(() -> {
            reservation.setId(id);
            return reservationRepository.save(reservation);
        });
    }

    public void deleteReservation(Long id) {
        reservationRepository.deleteById(id);
    }
}
