package com.rentplace.backend.services;

import com.rentplace.backend.models.Property;
import com.rentplace.backend.repositories.PropertyRepository;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class PropertyService {

    private final PropertyRepository propertyRepository;

    public PropertyService(PropertyRepository propertyRepository) {
        this.propertyRepository = propertyRepository;
    }

    public List<Property> getAllProperties() {
        return propertyRepository.findAll();
    }

    public Optional<Property> getById(Long id) {
        return propertyRepository.findById(id);
    }

    public Property createProperty(Property property) {
        return propertyRepository.save(property);
    }

    public Property updateProperty(Long id, Property property) {
        return propertyRepository.findById(id).map(existingProperty -> {
            existingProperty.setName(property.getName());
            existingProperty.setAddress(property.getAddress());
            existingProperty.setDescription(property.getDescription());
            existingProperty.setPricePerNight(property.getPricePerNight());
            return propertyRepository.save(existingProperty);
        }).orElseGet(() -> {
            property.setId(id);
            return propertyRepository.save(property);
        });
    }

    public void deleteProperty(Long id) {
        propertyRepository.deleteById(id);
    }
}
