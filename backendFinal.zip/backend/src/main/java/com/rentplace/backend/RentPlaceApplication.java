package com.rentplace.backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RentPlaceApplication {

	public static void main(String[] args) {
		SpringApplication.run(RentPlaceApplication.class, args);
	}
}
